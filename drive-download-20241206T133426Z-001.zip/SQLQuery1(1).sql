create database careem
use careem

create table driver(
ID int primary key,
Name nvarchar(50),
Phone nvarchar(11),
car_num nvarchar(6),
NIC nvarchar(12),
)

alter table driver
alter column NIC nvarchar(15)

create table customer(
ID int primary key,
Name nvarchar(50),
balance float,
Phone nvarchar(11),

)


create table rides(
ID int primary key,
date_ date,
To_loc nvarchar(50),
from_loc nvarchar(50),
type nvarchar(50),
status nvarchar(50),
cus_ID int foreign key references customer(ID),
driver_ID int foreign key references driver(ID)
)


create table location(
To_loc nvarchar(50),
from_loc nvarchar(50),
cus_ID int foreign key references customer(ID),
date_ date
)

insert into driver values
(1001,'Hashir','03122456879','BF7456','42201-7398564-4'),
(1002,'Ali','03128745879','BF7457','42201-6325479-3'),
(1003,'Haris','03122498754','BF7458','42201-7388369-1'),
(1004,'Siddique','03122463259','BF7459','42201-7396679-5'),
(1005,'Aryan','03335456879','BF7460','42201-7388999-9')

insert into customer values
(1101,'Sunbla',450,'03358656879'),
(1102,'Fatima',500,'03152656896'),
(1103,'Laiba',400,'03358696325'),
(1104,'Wajiha',320,'03358665412'),
(1105,'Hina',600,'03358653254')


insert into rides values
(2401,'2021-12-12','Block C, gulshan-e-iqbal','korangi crossing','GO mini','completed',1102,1005),
(2402,'2021-12-13','North Nazimabad','gulshan-e-iqbal','GO','cancelled',1103,1004),
(2403,'2021-12-20','malir','tariq road','GO+','completed',1104,1003),
(2404,'2021-12-17','North Nazimabad','gulshan-e-iqbal','GO+','completed',1102,1005),
(2405,'2021-12-18','defence','nursery','GO mini','completed',1105,1001)


insert into location values
('Block C, gulshan-e-iqbal','korangi crossing',1104,'2021-12-12'),
('North Nazimabad','nursery',1101,'2021-11-10'),
('defence','korangi crossing',1102,'2021-11-25'),
('korangi crossing','malir',1103,'2021-12-05'),
('North Nazimabad','defence',1105,'2021-12-15')


--------Task 1----------
select customer.ID,Name,balance, Phone from customer inner join rides on cus_ID = customer.ID 
where To_loc = 'North Nazimabad' and from_loc = 'gulshan-e-iqbal' and date_ > '2021-12-16' 

--------Task 2----------
select customer.ID,Name,balance, Phone, count(cus_ID) from customer inner join rides on cus_ID = customer.ID 
where type = 'Go+' group by customer.ID,Name,balance, Phone having count(cus_ID)> 5 

--------Task 3----------
select * from rides full join customer on cus_ID = customer.ID
full join driver on driver_ID = driver.ID 

--------Task 4----------
select top 2 ID,Name, phone,max(balance) as balance from customer group by ID,Name, phone order by max(balance) DESC

--------Task 5: Fetch all riders that have completed more than 3 rides in last 7 days----------
select driver.ID,Name, phone,car_num,NIC,cus_ID, date_,To_loc,from_loc,type,status,count(driver_ID)
 from driver inner join rides on driver_ID = driver.ID 
 where driver_ID = (select * from rides where rides.date_ > '2021-12-14' and status = 'completed')
group by driver.ID,Name, phone,car_num,NIC,cus_ID, date_,To_loc,from_loc,type,status
 having count(driver_ID)>3 