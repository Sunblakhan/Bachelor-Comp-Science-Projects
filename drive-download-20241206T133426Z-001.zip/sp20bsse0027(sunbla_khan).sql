create database paper

use paper


------------Question no 01(a)--------------------

create table customer(
id int identity(1,1) primary key,
name nvarchar(20) not null,
acc_details bigint,
contact nvarchar(20),
address nvarchar(50)

)

create table product(
id int primary key,
name nvarchar(50),
price float
)

create table invoice(
invoice_num int primary key,
date_ date,
prod_id int foreign key references product(id),
quantity int,
total_amount float,
cus_ID int foreign key references customer(id)

)

insert into customer values
('Sunbla',112301,'+923459875497','Gulshan Iqbal'),
('Fatima',112302,'+923569856699','North Nazimabad'),
('Laiba',112303,'+921369875495','North Nazimabad')

update invoice set date_ = '2022-01-17' where invoice_num = 4501

insert into product values
(1121,'Rice',765),
(1122,'Potato',100),
(1123,'Onion',120)

insert into invoice values
(4501,'2021-12-01',1121,3,2295, 1),
(4502,'2022-01-10',1122,5,500, 2),
(4503,'2022-01-12',1123,2,240, 3)

insert into invoice(invoice_num,date_,prod_id,quantity,cus_ID) values
(4509,'2022-01-15',1122,8,2)

select * from invoice

------------Question no 01(b)--------------------

--------Task 1-----------

select p.id,p.name,p.price from product p, invoice i,customer c 
where p.id = i.prod_id and i.cus_ID = c.id and address = 'North Nazimabad' 
and quantity = (select top 1 quantity from invoice order by quantity desc)

--------Task 2-----------

select sum(total_amount) as [Total Sal] from invoice 
where prod_id = (select id from product where name = 'Rice') and
datediff(day,date_,getdate()) = 2

---------Task 3-------------

select top 3 id,name,address,contact,acc_details from customer where id = 
(select id from invoice where prod_id = 
(select id from product where price = (select max(price) from product)))

------------Trigger 1------------
create trigger calculate
on invoice
for insert
as begin
declare @unitprice float = (select price from product where id = (
select prod_Id from inserted))
declare @id int = (select prod_id from inserted)
declare @quantity int = (select quantity from inserted)
declare @total float = @quantity * @unitprice 
update invoice set total_amount = @total where 
prod_id = @id and invoice_num = (select invoice_num from inserted)

end

drop trigger calculate

------------Trigger 2------------
create trigger prevent
on invoice
instead of insert
as begin
declare @quantity int = (select quantity from inserted) 
if @quantity > 4 
	print 'quantity can not be greater than 4'
else
	declare @invoice_num int,
	declare @date_ date= (select cus_ID from inserted)
	declare @prod_id int = (select cus_ID from inserted)
	declare @quantity int = (select cus_ID from inserted)
	declare @total_amount float = (select cus_ID from inserted)
	declare @cus_ID int  = (select cus_ID from inserted)
	insert into invoice	values(@invoice_num, @date_, @prod_id, @quantity, @total_amount, @cus_ID)
end


--------------Question no 02(a)----------

create table employee(
id int identity(1,1) primary key,
name nvarchar(50),
designation nvarchar(50),
bas_sal float,
med_allowence float,
mon_bon float,
mon_late int,
curr_sal float
)

drop table employee

insert into employee values
('Ali Khan','System Administrator',100000,10000,5000,4,0),
('Bilal Raza','Database Administrator',75000,7500,4000,2,0),
('Aali Arshad','Manager',135000,13500,7000,4,0),
('Usman Khan','Senior Manager',175000,17500,8000,5,0),
('Mustafa','Senior System Administrator',125000,12500,6000,4,0),
('Obaid Chandio','Director',250000,25000,10000,5,0)

--------------Question no 02(b)----------

-------------Task 1-----------
select * from employee where name like '%Khan'

-------------Task 2-----------
select designation from employee where mon_bon > 6000

-------------Task 3-----------
update employee set curr_sal = bas_sal + med_allowence + mon_bon 

-------------Task 4-----------
select REPLACE(name,'i','_') from employee

------------Task 5-----------
select CONCAT(SUBSTRING(name,1,3),SUBSTRING(designation,len(designation)-1,2))
from employee


-------------Question no 03(a)-------------
create table user_(
id int identity(1,1) primary key,
name nvarchar(50),
age int,
address nvarchar(50),
mobile nvarchar(50) unique

)

create table book(
ISBN int identity(1,1) primary key,
title nvarchar(50),
publish_year int,
rent float,
)

create table issue(

id int identity(1,1) primary key,
date_ date,
return_days int,
user_id int foreign key references user_(id),
ISBN int foreign key references book(ISBN)
)

create trigger checkissue
on issue
instead of insert
as begin

declare @returndays = (select return_days from inserted)
declare @total = (select count(ISSB) from issue where user_id = (select user_id from inserted))

if @returndays <= 2
	begin
	if @total > 3
		print 'you can not issue more than 3 books at a time' 
	else
		insert into issue values(select * from inserted)
	end
else
	print 'you can not issue book for more than 2 days'
end






-------------Question no 03(b)-------------

create procedure calculaterent @rent float, @return_days int
as begin
declare @totalrent float
declare @return_day int = (select return_days from issue)
declare @rentperday int = (select rent from book)
if @return_day <2
	begin
	set @totalrent = @return_day * @rentperday
	print concat('total rent: ', @totalrent)
	end
else
	begin
	print ' return days can not be more than 2'
	end

end
drop procedure calculaterent

begin
exec calculaterent 56,2 
end

-------------Question no 03(c)-------------
create procedure list @id int
as begin
select * from book where ISBN = (select ISBN from issue where user_id = @id)
end


begin
exec list 1
end



