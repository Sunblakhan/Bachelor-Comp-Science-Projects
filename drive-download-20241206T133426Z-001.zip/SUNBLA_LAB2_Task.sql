CREATE DATABASE TASK1

USE TASK1

CREATE TABLE UNIVERSITY(
	name nvarchar(50) PRIMARY KEY, 
	address nvarchar(50),
	type nvarchar(50), 
	VC nvarchar(50)
)

CREATE TABLE FACULTY(
	name nvarchar(50) PRIMARY KEY, 
	dean nvarchar(50),
	location nvarchar(50), 
	university_name nvarchar(50) FOREIGN KEY REFERENCES UNIVERSITY(name) 
)

CREATE TABLE SCHOOL(
	name nvarchar(50) PRIMARY KEY,
	hod nvarchar(50),
	location nvarchar(50),
	faculty_name nvarchar(50) FOREIGN KEY REFERENCES FACULTY(name)
)

CREATE TABLE PROGRAM(
	name nvarchar(50) PRIMARY KEY,
	total_credits int,
	duration int,
	school_name nvarchar(50) FOREIGN KEY REFERENCES SCHOOL(name)
)

CREATE TABLE COURSE(
	code int PRIMARY KEY,
	name nvarchar(50),
	credit_hour int,
	coordinator nvarchar(50),
	Program_name nvarchar(50) FOREIGN KEY REFERENCES PROGRAM(name)
)

CREATE TABLE LECTURER(
	emp_code int PRIMARY KEY,
	name nvarchar(50),
	designation nvarchar(50),
	room nvarchar(50),
	school_name nvarchar(50) FOREIGN KEY REFERENCES SCHOOL(name)
)

CREATE TABLE STUDENT(
	reg_no int PRIMARY KEY,
	name nvarchar(50),
	program_name nvarchar(50) FOREIGN KEY REFERENCES PROGRAM(name),
	email nvarchar(50),
	cell int,
	address nvarchar(50)
)

CREATE TABLE COURSE_REGISTRATION(
	date nvarchar(50),
	assigned_by nvarchar(50),
	std_reg_no int FOREIGN KEY REFERENCES STUDENT(reg_no),
	course_code int FOREIGN KEY REFERENCES COURSE(code),
	PRIMARY KEY(std_reg_no, course_code)
	
)

CREATE TABLE COURSE_ALLOCATION(
	date nvarchar(50),
	assigned_by nvarchar(50),
	EMP_code int FOREIGN KEY REFERENCES LECTURER(emp_code),
	course_code int FOREIGN KEY REFERENCES COURSE(code),
	PRIMARY KEY(EMP_code, course_code)
)


