
use Practice


------Task 1-------

create procedure Empinfo
begin
select * from EMPLOYEE
end;

exec Empinfo

----------Task 2------

create procedure Display_Emp(@desno int)
as
begin
	select * from employee where DES_KEY=@desno
end

exec Display_Emp

----------Task 3------

create procedure  Display_Designation(@empId int)
as
begin
	select TITLE from Designation where ID=(select DES_KEY from EMPLOYEE where id=@empId)
end

exec Display_Designation 3

----------Task 4------

create procedure classified(@pass int)
as
begin
	if(len(@pass)=4)
		if(@pass=4231)
			select * from EMPLOYEE
		else
			print('PASSWORD INCORRECT')
	else
		print ('Password can be 4 digit only')
end

exec Classified 4233

----------Task 5------

create procedure func(@name nvarchar(50), @age int)
as 
begin
if (len(@name)>=3)
	if(@age>16)
		insert into tab1 values(@name,@age)
	else
	print 'age can not be less than 16'
else
	print 'name must have minimum 3 characters'

end;

exec func 'Ali',12

----------Task 6------

create procedure VALIDATE(@ID int,@name nvarchar(50), @age int)
as 
begin
if exists (select ID from tab2 where ID = @ID)
	print 'ID exist'
else
	insert into tab2 values(@ID,@name,@age)

end;

exec validate 1,'ali',17

----------Task 7------

create procedure calculate(@key int)
as 
begin
select name, salary, 
case 
when @key = 1 then salary * 0.05
when @key = 2 then salary * 0.1
else salary * 0.15
end as bonus
from EMPLOYEE
end;

exec calculate 1

