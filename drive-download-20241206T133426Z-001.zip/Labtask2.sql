create table EMPLOYE1(
 ID INT PRIMARY KEY,
 NAME NVARCHAR(50),
 DESIG NVARCHAR(50),
 SAL INT,
 MEDALL INT,
 BONUS INT,
 LATE INT,
 CURSAL INT, 
)

insert into EMPLOYE1 values
(1,'Ali Khan','System Administrator', 100000, 10000,5000,4,110000),
(2,'Bilal Raza','Database Administrator', 75000, 7500,4000,2,82500),
(3,'Aali Arshad','Manager', 135000, 13500,7000,4,148500),
(4,'Usman Khan','Senior Manager', 175000, 17500,8000,5,192000),
(5,'Mustafa','Senior System Administrator', 125000, 12500,6000,4,137500),
(6,'Obaid Chandio','Director', 250000, 25000,10000,5,275000)

update EMPLOYE1 set BONUS = 5000 
update EMPLOYE1 set MEDALL+=2000 where SAL < 125000
update EMPLOYE1 set BONUS = 0 where LATE >=3 AND DESIG not in ('Manager','Director','Senior Manager')
update EMPLOYE1 set CURSAL=CURSAL+BONUS

select * from EMPLOYE1